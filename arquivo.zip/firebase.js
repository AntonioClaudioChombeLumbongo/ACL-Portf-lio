  import { initializeApp } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-app.js";
  import { getAuth } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-auth.js";
  import { getDatabase, ref, push, set, get, update, remove, onValue } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-database.js";
  import { getFirestore } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-firestore.js";
  import { getStorage } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-storage.js";

  const firebaseConfig = {
    apiKey: "AIzaSy...",
    authDomain: "acl-tech.firebaseapp.com",
    projectId: "acl-tech",
    storageBucket: "acl-tech.appspot.com",
    messagingSenderId: "784507649414",
    appId: "1:784507649414:web:3c74db4d0bed04cd85c007",
    databaseURL: "https://acl-tech-default-rtdb.firebaseio.com"
  };

  // Inicializa serviços
  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app);
  const rtdb = getDatabase(app);
  const db = getFirestore(app);
  const storage = getStorage(app);